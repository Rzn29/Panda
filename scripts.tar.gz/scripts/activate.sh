#!/system/bin/sh
SDK=$(echo $(getprop ro.build.version.sdk))
echo $SDK
O=26

if [ $SDK -lt $O ]; then
    PS_ARGS=""
else
    PS_ARGS="-A"
fi

set a=`ps $PS_ARGS | grep com.android.adnap:daemon`;
if [ $2 ]; then
    echo '1'
    kill $2
    kill -9 $2
fi

set a=`ps $PS_ARGS | grep com.panda.gamepad:i`;
if [ $2 ]; then
    echo '2'
    kill $2
    kill -9 $2
fi

set a=`ps $PS_ARGS | grep com.panda.mouse:i`;
if [ $2 ]; then
    echo '3'
    kill $2
    kill -9 $2
fi

TMP_PATH=/data/local/tmp/2

sleep 1

settings put global block_untrusted_touches 0
mkdir $TMP_PATH
cp -r /sdcard/Android/data/com.panda.gamepad/files/scripts/* $TMP_PATH
cp -r /sdcard/Android/data/com.panda.mouse/files/scripts/* $TMP_PATH
cp -r /sdcard/Android/data/com.panda.gamepad/files/scripts/com.panda.gamepadinject.dex $TMP_PATH
cp -r /sdcard/Android/data/com.panda.gamepad/files/scripts/com.panda.gamepadlibinject.so $TMP_PATH
cp -r /sdcard/Android/data/com.panda.gamepad/files/scripts/x64com.panda.gamepadlibinject.so $TMP_PATH
chmod -R 777 $TMP_PATH
sh $TMP_PATH/inject2.sh