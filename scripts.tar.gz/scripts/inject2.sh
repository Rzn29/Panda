#!/system/bin/sh
SDK=$(echo $(getprop ro.build.version.sdk))
echo $SDK
O=26

if [ $SDK -lt $O ]; then
    PS_ARGS=""
else
    PS_ARGS="-A"
fi

set a=`ps $PS_ARGS | grep com.android.adnap:daemon`;
if [ $2 ]; then
    echo '1'
    kill $2
    kill -9 $2
fi

set a=`ps $PS_ARGS | grep com.panda.gamepad:i`;
if [ $2 ]; then
    echo '2'
    kill $2
    kill -9 $2
fi

set a=`ps $PS_ARGS | grep com.panda.mouse:i`;
if [ $2 ]; then
    echo '3'
    kill $2
    kill -9 $2
fi

TMP_PATH=/data/local/tmp/2

sleep 1

chmod -R 777 $TMP_PATH

if [ -f /system/bin/app_process32 ]; then
    APP_PROCESS="app_process32"
else
    APP_PROCESS="app_process"
fi

if [ -e $TMP_PATH/com.panda.gamepadinject.dex ]; then
    (nohup $APP_PROCESS -Djava.class.path=$TMP_PATH/com.panda.gamepadinject.dex $TMP_PATH/ com.chaozhuo.gameassistant.inject.InjectService > /dev/null 2>&1 &)
fi

if [ -e $TMP_PATH/com.panda.mouseinject.dex ]; then
    (nohup $APP_PROCESS -Djava.class.path=$TMP_PATH/com.panda.mouseinject.dex $TMP_PATH/ com.chaozhuo.gameassistant.inject.InjectService > /dev/null 2>&1 &)
fi

sleep 2

SUCCESS=0
set a=`ps $PS_ARGS | grep com.panda.gamepad:i`;
if [ $2 ]; then
  SUCCESS=1
fi

if [ $SUCCESS -eq 0 ]; then
    APP_PROCESS="app_process"
    if [ -e $TMP_PATH/com.panda.gamepadinject.dex ]; then
        (nohup $APP_PROCESS -Djava.class.path=$TMP_PATH/com.panda.gamepadinject.dex $TMP_PATH/ com.chaozhuo.gameassistant.inject.InjectService > /dev/null 2>&1 &)
    fi
fi

SUCCESS=0
set a=`ps $PS_ARGS | grep com.panda.mouse:i`;
if [ $2 ]; then
  SUCCESS=1
fi

if [ $SUCCESS -eq 0 ]; then
    APP_PROCESS="app_process"
    if [ -e $TMP_PATH/com.panda.mouseinject.dex ]; then
        (nohup $APP_PROCESS -Djava.class.path=$TMP_PATH/com.panda.mouseinject.dex $TMP_PATH/ com.chaozhuo.gameassistant.inject.InjectService > /dev/null 2>&1 &)
    fi
fi