#!/system/bin/sh

nohup sh /data/local/tmp/2/inject2.sh > /dev/null 2>&1 &
